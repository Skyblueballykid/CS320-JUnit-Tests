package medical.com.medicalApplication.model;

import medical.com.medicalApplication.model.Patient;;
/**
 * 
 * 
 * This class represents a medical record model in the system
 *
 */
public class MedicalRecord {

	//Bug here, patient should be string type
	private Patient patient;
	private PatientHistory history;
	
	//Bug here, Medical Record should declare data types
	public MedicalRecord(Patient patient) {
		super();
		this.patient = patient;
		this.history = new PatientHistory();
	}

	//Bug, Should be string
	//Not this: public Patient getPatient() {
	public Patient getPatient() {
		return patient;
	}

	public PatientHistory getHistory() {
		return history;
	}
	
}
