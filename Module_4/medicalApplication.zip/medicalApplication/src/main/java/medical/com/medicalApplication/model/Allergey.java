package medical.com.medicalApplication.model;

import java.util.ArrayList;
import java.util.List;



/**
 * This class represent the Allergy model in the application
 *
 */
public class Allergey {
	private String name;
	
	//add an array to store the names of allergies
	private ArrayList<Class> allergies;
	
	private Allergey allergey;
	

	public Allergey(String name) {
		super();
		this.name = name;
		this.allergies = new ArrayList<Class>();

	}
	
	//add getter method for array
	public List<Class> getAllergies() {
		return allergies;
	}

	//add setter
	public void setAllergies(Class name) {
		this.allergies.add(name);
	}
	
	//getter method to get allergy (it was a bug that this didn't exist)
	public Allergey getAllergey() {
		return allergey;
	}

	//setter method to set new allergy (it was a bug that this didn't exist)
	public void setAllergey(Allergey allergey) {
		this.allergey = allergey;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Allergy " + name;
	}
	
}
